# Нагрузочное тестирование (ЛР №3 по ТиОПО)

## Benchmark #1. Latency(RPS)

### 3 cores

![Alt text](img/latency_cores_3.0.png)

![Alt text](img/metrics_cores_3.0.png)

### 2 cores

![Alt text](img/latency_cores_2.0.png)

![Alt text](img/metrics_cores_2.0.png)

## Benchmark #2. Stable RPS

### 3 cores

![Alt text](img/hist_rps_500.png)
